const config = {
    mongo: {},
    ec2: {
      EC2_NAME: process.env.EC2_NAME,
      EC2_AMI: process.env.EC2_AMI,
      EC2_PROFILE_ROLE: process.env.EC2_PROFILE_ROLE,
      EC2_SUBNETS: process.env.EC2_SUBNETS.split(','),
      EC2_SECURITY_GROUPS: process.env.EC2_SECURITY_GROUPS.split(',')
    },
    script: {
      S3_BUCKET: process.env.S3_BUCKET,
      S3_FILE_PATH: process.env.S3_FILE_PATH,
      S3_FILE_NAME: process.env.S3_FILE_NAME
    },
    tags_keys: process.env.TAG_KEYS.split(','),
    tags_values: process.env.TAG_VALUES.split(','),
  };

  const tags = [];
  for ( let i = 0; i < config.tags_keys.length; i++) {
    tags.push({
      Key: config.tags_keys[i],
      Value: config.tags_values[i]
    })
  }

  config.tags = tags;

module.exports = config;
