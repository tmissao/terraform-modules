const env = require('../config/config').aws;

const getScript = (bucket, bucketPath, filename) => `#!/bin/bash

# Debugging - prints every command and returns
set -x;
# Makes script exit if a commands fails
set -e;
# Makes de pipeline returns error if a command in pipeline fails
set -o pipefail;
# Makes script exit if a referenced variable is not declared
set -u;

#Variables
REGION=\`curl http://169.254.169.254/latest/dynamic/instance-identity/document|grep region|awk -F\\" '{print $4}'\`;
BUCKET=${bucket}
BUCKET_PATH=${bucketPath}
BUCKET_FILE=${filename}
FOLDER="data"

echo "##################### GETTING SCRIPT #######################"

mkdir -p "$FOLDER"
aws s3 cp "s3://$BUCKET$BUCKET_PATH$BUCKET_FILE" "./$FOLDER/$BUCKET_FILE"
chmod +x "$FOLDER/$BUCKET_FILE"

echo "#################### EXECUTING SCRIPT #######################"

bash "$FOLDER/$BUCKET_FILE"

echo "################## TERMINATING INSTANCE #####################"

aws ec2 terminate-instances --region "$REGION" --instance-ids $(curl http://169.254.169.254/latest/meta-data/instance-id);
`;

module.exports.getScript = getScript;
