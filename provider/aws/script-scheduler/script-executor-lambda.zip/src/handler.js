const env = require('../config/config');
const scriptBuilder = require('./script');

/** Handler Creaate a Forum */
class Handler {
  /**
   * @param {ec2Service} ec2Service An EC2 Service
   */
  constructor(ec2Service) {
    if (!ec2Service) {
      throw new Error('Invalid Constructor Args');
    }
    this._ec2Service = ec2Service;
  }

  async _startEc2(script) {
    const tags = [
      {
        Key: 'Name',
        Value: env.ec2.EC2_NAME
      },
      {
        Key: 'Schedule',
        Value: env.ec2.EC2_NAME
      }
    ].concat(env.tags)
    const base64 = Buffer.from(script).toString('base64');
    console.log(base64);
    const params = {
      ImageId: env.ec2.EC2_AMI,
      InstanceType: 't3.small',
      // KeyName: 'bastion-key',
      MaxCount: 1,
      MinCount: 1,
      SecurityGroupIds: env.ec2.EC2_SECURITY_GROUPS,
      SubnetId: env.ec2.EC2_SUBNETS[0],
      IamInstanceProfile: { Name: env.ec2.EC2_PROFILE_ROLE },
      UserData: base64,
      TagSpecifications: [
        {
          ResourceType: 'instance',
          Tags: tags
        },
        {
          ResourceType: 'volume',
          Tags: tags
        }
      ] 
    }

    const result = await this._ec2Service.runInstances(params).promise();
    return result;
  }

  _buildScript() {
    const args = env.script;
    const script = scriptBuilder.getScript(args.S3_BUCKET, args.S3_FILE_PATH, args.S3_FILE_NAME)
    console.log(script);
    return script;
  }

  /**
   * Start Method
   * @param {*} event
   * @param {*} context
   */
  async start(event, context) {
    if (!event) {
      throw new Error(`Invalid Validate Args - : ${event}`);
    }

    const script = this._buildScript();
    const result = await this._startEc2(script);
    console.log(result);
    return result;
  }
}


module.exports = Handler;
