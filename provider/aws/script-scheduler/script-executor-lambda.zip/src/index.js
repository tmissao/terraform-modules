const AWS = require('aws-sdk');
const Handler = require('./handler');

const ec2Service = new AWS.EC2();

let instance = null;

const _init = () => {
  instance = new Handler(ec2Service);
};

const handler = (event, context) => {
  if (!instance) {
    _init();
  }
  return instance.start(event, context);
};

exports.handler = handler;
